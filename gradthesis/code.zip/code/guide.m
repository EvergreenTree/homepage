%%this is how it works for algorithms in the paper:

%assemble .mat file
temp=readtable('balance-scale.data.txt');
X=temp(:,2:end);
Y=temp(:,1);

%load mat
wine=load('wine.mat');
MNIST=('MNIST.mat');
iris=load('iris.mat');


%test model
testmlmodel(X,Y);


