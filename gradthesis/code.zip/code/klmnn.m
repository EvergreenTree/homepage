function [L, Phi, det] = klmnn(X,Y,Kg)
%KLMNN Summary of this function goes here
%Phi: kernel space of full(dim=n) kernel PCA

[n d]=size(X);

%KPCA
[Phi mapping]=mk_pca(X,n,'gauss',10);
Phi=real(Phi);
[L det]=lmnnCG(Phi',Y',Kg);

end

