function [err_2fold err_train] = crossvalidation( mdl, n)
%CROSSVAL Summary of this function goes here
%   Detailed explanation goes here
if nargin<2 n=1; end
Err=zeros(n,1);
Err2=zeros(n,1);
for i=1:n
cvmdl=crossval(mdl,'kfold',2);
Err(i)=kfoldLoss(cvmdl);
Err2(i)=resubLoss(mdl);
end

err_2fold=mean(Err);
err_train=mean(Err2);
end

