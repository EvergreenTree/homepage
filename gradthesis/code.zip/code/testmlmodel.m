function testmlmodel(X,Y)
%TESTMLMODEL Summary of this function goes here
%   Detailed explanation goes here
[n d]=size(X);
err_2fold=zeros(6,1);err_train=zeros(6,1);
%Euclidian
mdl = fitcknn(X,Y);
[err_2fold(1) err_train(1)]=crossvalidation(mdl);
sprintf('Euclidian (2fold/train) = %d / %d',err_2fold(1),err_train(1))
%Sample Cov
mdl = fitcknn(X,Y,'Distance','Mahalanobis');
[err_2fold(2) err_train(2)]=crossvalidation(mdl);
sprintf('sample cov (2fold/train) = %d / %d',err_2fold(2),err_train(2))
%Standard Euclidean
mdl = fitcknn(X,Y,'Distance','seuclidean');
[err_2fold(3) err_train(3)]=crossvalidation(mdl);
sprintf('Standard Euclidean (2fold/train) = %d/%d',err_2fold(3),err_train(3))
%LDA
mX=lda(X,Y,30);mX=real(mX);
mdl=fitcknn(mX,Y);
[err_2fold(4) err_train(4)]=crossvalidation(mdl);
sprintf('LDA (2fold/train) = %d/%d',err_2fold(4),err_train(4))
%lmnn
L=lmnnCG(X',Y',5);
    X1=X*L';
    Y1=Y';
    mdl=fitcknn(X1,Y1);
[err_2fold(5) err_train(5)]=crossvalidation(mdl);
sprintf('lmnn (2fold/train) = %d/%d',err_2fold(5),err_train(5))
%lmnn-kernel
[L, Phi, ~]=klmnn(X,Y,5);
    X2=Phi*L';
    Y2=Y';
    mdl=fitcknn(X2,Y2);
[err_2fold(6) err_train(6)]=crossvalidation(mdl);
sprintf('lmnn-kernel (2fold/train) = %d/%d',err_2fold(6),err_train(6))

%lmnn-multikernel-NR
[L, Phi, Y,~]=mklmnn(X,Y,5);
    X2=Phi*L';
    Y2=Y';
    mdl=fitcknn(X2,Y2);
[err_2fold(7) err_train(7)]=crossvalidation(mdl);
sprintf('lmnn-multikernel-NR (2fold/train) = %d/%d',err_2fold(7),err_train(7))

%lda-builtin
mdl=fitcdiscr(X,Y);
[err_2fold(8) err_train(8)]=crossvalidation(mdl);
sprintf('lda-builtin (2fold/train) = %d/%d',err_2fold(4),err_train(4))


end

