function [L, PHI,YY, det] = mklmnn(X,Y,Kg)
%KLMNN Summary of this function goes here
%Phi: kernel space of full(dim=n) kernel PCA
Sigma=[0.5, 1, 2, 5, 7, 10, 12, 15, 17, 20]
[n d]=size(X);

Phi=cell(0);
%KPCA
for i=1:10
[Phi{i} mapping]=mk_pca(X,n,'gauss',Sigma(i));
%if(imag(Phi{i}(1)))
end
%PHI=blkdiag(Phi{1},Phi{2},Phi{3},Phi{4},Phi{5},Phi{6},Phi{7},Phi{8},Phi{9},Phi{10}),
PHI=real(cat(1,Phi{1},Phi{2},Phi{3},Phi{4},Phi{5},Phi{6},Phi{7},Phi{8},Phi{9},Phi{10}));
YY=cat(1,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y);
[L det]=lmnnCG(PHI',YY',Kg);


end

