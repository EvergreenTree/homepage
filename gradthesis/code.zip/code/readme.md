##Readme.md

As is shown in guide.m, load data matrix as X, label as Y, each row for one data case, and run testmlmodel(X,Y). This function prints the outcome in the paper

Supporting reference materials are provided alongside this code.

Website:
[http://changqingfu.com/gradthesis.html]()